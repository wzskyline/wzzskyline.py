// 来源类型
export const SOURCE_TYPE = {
  'COMPONENT': 'COMPONENT',
  'COMMAND': 'COMMAND',
}