// Context 管理器

// React libs
import React, { createContext } from 'react'

export const Context = createContext()